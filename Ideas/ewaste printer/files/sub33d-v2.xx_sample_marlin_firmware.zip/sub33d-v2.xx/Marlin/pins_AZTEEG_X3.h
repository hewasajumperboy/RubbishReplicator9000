/**
 * AZTEEG_X3 Arduino Mega with RAMPS v1.3 pin assignments
 */

#include "pins_RAMPS_13.h"
